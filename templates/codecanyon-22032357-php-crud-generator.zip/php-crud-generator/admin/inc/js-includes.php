<?php
if (ENVIRONMENT === 'development') {
    ?>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/pace.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/ripple.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/footable.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/colorcolumns.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/jquery.qtip.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/jeditable.min.js"></script>
    <?php
} else {
        ?>
        <script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/all.min.js"></script>
<?php
}
?>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/fontawesome-all.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/plugins/jquery.floatThead.min.js"></script>
<script type="text/javascript" src="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/picker.js"></script>
<script type="text/javascript" src="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/picker.date.js"></script>
<script type="text/javascript" src="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/picker.time.js"></script>
<!-- <script type="text/javascript" src="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/translations/fr_FR.js"></script> -->
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>assets/javascripts/project.js"></script>
