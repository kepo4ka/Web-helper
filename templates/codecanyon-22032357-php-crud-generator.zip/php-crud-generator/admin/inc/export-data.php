<?php
use secure\Secure;
use export\ExportData;
use export\ExportDataExcel;
use export\ExportDataCSV;
use export\ExportDataTSV;
use phpformbuilder\database\Mysql;

session_start();
include_once '../../conf/conf.php';
include_once ADMIN_DIR . 'secure/class/secure/Secure.php';
include_once ADMIN_DIR . 'class/export/ExportData.php';

// lock page
Secure::lock();

if (!isset($_GET['table']) || !isset($_GET['format']) || !preg_match('`excel|csv|tsv`', $_GET['format'])) {
    exit();
}
$table = addslashes($_GET['table']);
$format = $_GET['format'];
if (!isset($_SESSION['export'][$table]['sql'])) {
    exit();
}
$qry = $_SESSION['export'][$table]['sql'];
$db = new Mysql();
$columns = $db->getColumnNames($table);
$db->query($qry);
$nbre = $db->rowCount();
if (!empty($nbre)) {
    if ($format == 'excel') {
        $exporter = new ExportDataExcel('browser', $table . '.xls');
    } elseif ($format == 'csv') {
        $exporter = new ExportDataCSV('browser', $table . '.csv');
    } else {
        $exporter = new ExportDataTSV('browser', $table . '.tsv');
    }
    $exporter->initialize();
    $exporter->addRow($columns);
    while (! $db->endOfSeek()) {
        $result = array();
        $row = $db->row();
        foreach ($columns as $column_name) {
            $result[] = $row->$column_name;
        }
        $exporter->addRow($result);
    }
    $exporter->finalize();
    exit();
}
