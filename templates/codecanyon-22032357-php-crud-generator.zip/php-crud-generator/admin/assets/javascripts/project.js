'use strict';

// use window.onload instead of $(document).ready because it waits for the defered scripts to load
window.onload = function() {
    /* global define, console */

    /*===============================
    =            Sidebar            =
    ===============================*/

    if ($('.sidebar')[0]) {
        if ($(window).width() > 768) {
            $('.sidebar').removeClass('collapse');

            // Expand the 1st category
            if ($('.sidebar-category .dropdown-toggle[aria-expanded="true"]').length < 1) {
                var firstDropdown = $('#sidebar-main')
                    .find('.dropdown-toggle')
                    .get(0);
                if ($(firstDropdown)[0]) {
                    $(firstDropdown).trigger('click');
                }
            }
        }
        $(window)
            .on('resize', function() {
                setTimeout(function() {
                    if ($(window).width() > 768) {
                        $('.sidebar')
                            .removeClass('collapse')
                            .addClass('show');
                        $('.sidebar-toggler')
                            .removeClass('collapsed')
                            .attr('aria-expanded', 'true');
                    } else {
                        $('.sidebar')
                            .addClass('collapse')
                            .removeClass('show');
                        $('.sidebar-toggler')
                            .addClass('collapsed')
                            .attr('aria-expanded', 'false');
                    }
                }, 100);
            })
            .resize();

        // sidebar mini toggle
        if ($('.sidebar-mini-toggler')[0]) {
            $('.sidebar-mini-toggler').on('click', function() {
                if ($('#sidebarFiltersNav')[0]) {
                    $('#sidebarFiltersNav')
                        .prev('.category-title')
                        .find('a.dropdown-toggle:not(.collapsed)')
                        .trigger('click');
                }
                $(this)
                    .closest('.sidebar-container')
                    .toggleClass('has-mini')
                    .find('.sidebar')
                    .toggleClass('sidebar-mini');
                // .find('a.dropdown-toggle:not(.collapsed)')
                // .trigger('click');
            });
        }
    }
};
