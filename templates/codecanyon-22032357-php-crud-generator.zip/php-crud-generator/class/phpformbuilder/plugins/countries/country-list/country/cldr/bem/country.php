<?php return array (
  'ZM' => 'Zambia',
);
