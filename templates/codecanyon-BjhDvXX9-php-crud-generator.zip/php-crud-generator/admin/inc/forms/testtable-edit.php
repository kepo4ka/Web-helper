<?php
use phpformbuilder\Form;
use fileuploader\server\FileUploader;
use phpformbuilder\Validator\Validator;
use phpformbuilder\database\Mysql;
use common\Utils;
use secure\Secure;

include_once ADMIN_DIR . 'secure/class/secure/Secure.php';
include_once CLASS_DIR . 'phpformbuilder/plugins/fileuploader/server/class.fileuploader.php';

/* =============================================
    validation if posted
============================================= */

if ($_SERVER["REQUEST_METHOD"] == "POST" && Form::testToken('form-edit-test-table') === true) {
    include_once CLASS_DIR . 'phpformbuilder/Validator/Validator.php';
    include_once CLASS_DIR . 'phpformbuilder/Validator/Exception.php';
    $validator = new Validator($_POST);
    $validator->required()->validate('set_column.0');
    $count = count($_POST['set_column']);
    for ($i=0; $i < $count; $i++) {
        $validator->oneOf('value 1,value 2,value 3,value 4')->validate('set_column.' . $i);
    }
    $validator->required()->validate('select_multiple_test.0');
    $json_value = json_encode($_POST['select_multiple_test']);
    $validator->maxLength(400)->validate($json_value, JSON_UNESCAPED_UNICODE);
    $validator->required()->validate('checkbox.0');
    $count = count($_POST['checkbox']);
    for ($i=0; $i < $count; $i++) {
        $validator->integer()->validate('checkbox.' . $i);
    }
    $count = count($_POST['checkbox']);
    for ($i=0; $i < $count; $i++) {
        $validator->min(0)->validate('checkbox.' . $i);
    }
    $count = count($_POST['checkbox']);
    for ($i=0; $i < $count; $i++) {
        $validator->max(1)->validate('checkbox.' . $i);
    }
    $json_value = json_encode($_POST['checkbox']);
    $validator->maxLength(400)->validate($json_value, JSON_UNESCAPED_UNICODE);
    if (!empty($_POST['single_select'])) {
        $validator->hasLowercase()->validate('single_select');
        $validator->hasUppercase()->validate('single_select');
        $validator->hasNumber()->validate('single_select');
        $validator->minLength(3)->validate('single_select');
        $validator->maxLength(200)->validate('single_select');
    } // end password optional validation
    $validator->required()->validate('date_test');
    if (isset($_POST['date_test_submit'])) {
        $validator->date()->validate('date_test_submit');
    } else {
        $validator->date()->validate('date_test');
    }
    $validator->maxLength(200)->validate('upload_file');
    $validator->maxLength(200)->validate('upload_image');
    $validator->required()->validate('tinymce');

    // check for errors
    if ($validator->hasErrors()) {
        $_SESSION['errors']['form-edit-test-table'] = $validator->getAllErrors();
    } else {
        require_once CLASS_DIR . 'phpformbuilder/database/db-connect.php';
        require_once CLASS_DIR . 'phpformbuilder/database/Mysql.php';
        $db = new Mysql();
        if (is_array($_POST['set_column'])) {
            $values = implode(',', $_POST['set_column']);
            $update['set_column'] = Mysql::SQLValue($values);
        } else {
            $update['set_column'] = Mysql::SQLValue($_POST['set_column'], Mysql::SQLVALUE_TEXT);
        }
        $update['select_multiple_test'] = Mysql::SQLValue($_POST['select_multiple_test'], Mysql::SQLVALUE_BOOLEAN);
        $update['checkbox'] = Mysql::SQLValue($_POST['checkbox'], Mysql::SQLVALUE_BOOLEAN);
        if (!empty($_POST['single_select'])) {
            $password = Secure::encrypt($_POST['single_select']);
            $update['single_select'] = Mysql::SQLValue($password, Mysql::SQLVALUE_TEXT);
        }
    $value = $_POST['date_test'];
    if (isset($_POST['date_test_submit'])) {
        $value = $_POST['date_test_submit'];
    }
    $update['date_test'] = Mysql::SQLValue($value, Mysql::SQLVALUE_DATE);
        if (!empty($_POST['upload_file']) && $_POST['upload_file'] != '[]') {
            $posted_file = FileUploader::getPostedFiles($_POST['upload_file']);
            $update['upload_file'] = Mysql::SQLValue($posted_file[0]['file'], Mysql::SQLVALUE_TEXT);
        } else {
            $update['upload_file'] = Mysql::SQLValue('', Mysql::SQLVALUE_TEXT);
        }
        if (!empty($_POST['upload_image']) && $_POST['upload_image'] != '[]') {
            $posted_img = FileUploader::getPostedFiles($_POST['upload_image']);
            $update['upload_image'] = Mysql::SQLValue($posted_img[0]['file'], Mysql::SQLVALUE_TEXT);
        } else {
            $update['upload_image'] = Mysql::SQLValue('', Mysql::SQLVALUE_TEXT);
        }
        $update['tinymce'] = Mysql::SQLValue($_POST['tinymce'], Mysql::SQLVALUE_TEXT);
        $filter["ID"] = Mysql::SQLValue($_SESSION['test_table_editable_primary_key'], Mysql::SQLVALUE_NUMBER);
        $db->throwExceptions = true;
        try {
            // begin transaction
            $db->transactionBegin();

            // update test_table
            if (!$db->updateRows('test_table', $update, $filter)) {
                $error = $db->error();
                $db->transactionRollback();
                throw new \Exception($error);
            } else {
                if (!isset($error)) {
                    // ALL OK
                    $db->transactionEnd();
                    $_SESSION['msg'] = Utils::alert(UPDATE_SUCCESS_MESSAGE, 'alert-success has-icon');

                    // reset form values
                    Form::clear('form-edit-test-table');

                    // redirect to list page
                    if (isset($_SESSION['active_list_url'])) {
                        header('Location:' . $_SESSION['active_list_url']);
                    } else {
                        header('Location:http://test.phpcrudgenerator.com/admin/testtable');
                    }

                    // if we don't exit here, $_SESSION['msg'] will be unset
                    exit();
                }
            }
        } catch (\Exception $e) {
            $msg_content = DB_ERROR;
            if (ENVIRONMENT == 'development') {
                $msg_content .= '<br>' . $e->getMessage() . '<br>' . $db->getLastSql();
            }
            $_SESSION['msg'] = Utils::alert($msg_content, 'alert-danger has-icon');
        }
    } // END else
} // END if POST
$ID = $pk;

// register editable primary key, which is NOT posted and will be the query update filter
$_SESSION['test_table_editable_primary_key'] = $ID;

if (!isset($_SESSION['errors']['form-edit-test-table']) || empty($_SESSION['errors']['form-edit-test-table'])) { // If no error registered
    $qry = "SELECT * FROM `test_table`";

    $transition = 'WHERE';

    // if restricted rights
    if (ADMIN_LOCKED === true && Secure::canUpdateRestricted('test_table')) {
        $qry .= Secure::getRestrictionQuery('test_table');
        $transition = 'AND';
    }
    $qry .= ' ' . $transition . " test_table.ID = '$ID'";

    $db = new Mysql();
    $db->query($qry);
    if ($db->rowCount() < 1) {
        if (DEBUG === true) {
            exit($db->getLastSql() . ' : No Record Found');
        } else {
            Secure::logout();
        }
    }
    $row = $db->row();
    $_SESSION['form-edit-test-table']['ID'] = $row->ID;
    $values = explode(',', $row->set_column);
    $_SESSION['form-edit-test-table']['set_column'] = array();
    if (!empty($values)) {
        foreach ($values as $value) {
            $_SESSION['form-edit-test-table']['set_column'][] = $value;
        }
    }
    $values = json_decode($row->select_multiple_test, true);
    $_SESSION['form-edit-test-table']['select_multiple_test'] = array();
    if (!empty($values)) {
        foreach ($values as $value) {
            $_SESSION['form-edit-test-table']['select_multiple_test'][] = $value;
        }
    }
    $values = json_decode($row->checkbox, true);
    $_SESSION['form-edit-test-table']['checkbox'] = array();
    if (!empty($values)) {
        foreach ($values as $value) {
            $_SESSION['form-edit-test-table']['checkbox'][] = $value;
        }
    }
    $_SESSION['form-edit-test-table']['single_select'] = '';
    $_SESSION['form-edit-test-table']['date_test'] = $row->date_test;
    $_SESSION['form-edit-test-table']['upload_file'] = $row->upload_file;
    $_SESSION['form-edit-test-table']['upload_image'] = $row->upload_image;
    $_SESSION['form-edit-test-table']['tinymce'] = $row->tinymce;
}
$form = new Form('form-edit-test-table', 'horizontal', 'novalidate', 'bs4');
$form->setMode('development');
$form->setAction('/admin/testtable/edit/' . $ID);
$form->startFieldset();

// set_column[] --

$form->setCols(2, 10);
$form->addOption('set_column[]', 'value 1', 'value 1');
$form->addOption('set_column[]', 'value 2', 'value 2');
$form->addOption('set_column[]', 'value 3', 'value 3');
$form->addOption('set_column[]', 'value 4', 'value 4');
$form->addSelect('set_column[]', 'Set Column', 'required, class=select2, multiple');

// select_multiple_test --
$form->addRadio('select_multiple_test', YES, 1);
$form->addRadio('select_multiple_test', NO, 0);
$form->printRadioGroup('select_multiple_test', 'Select Multiple Test', true, 'required');

// checkbox --
$form->addRadio('checkbox', YES, 1);
$form->addRadio('checkbox', NO, 0);
$form->printRadioGroup('checkbox', 'Checkbox', true, 'required');

// single_select --
$form->addPlugin('passfield', '#single_select', 'lower-upper-number-min-3');
$form->addHelper(PASSWORD_EDIT_HELPER, 'single_select');
$form->addInput('password', 'single_select', '', 'Single Select', '');

// date_test --
$form->addPlugin('pickadate', '#date_test', 'custom-date', array('%format%' => 'dd mmmm yyyy'));
$form->addInput('text', 'date_test', '', 'Date Test', 'required');

// upload_file --
$form->addHtml('<span class="form-text text-muted">Authorized files: doc, docx, xls, xlsx, pdf, txt</span>', 'upload_file', 'after');
$uniqid = uniqid();
$form->addHtml('<div id="' . $uniqid . '" style="display:none">
Authorized files: doc, docx, xls, xlsx, pdf, txt</div>');
// get current file if exists
$current_file = '';
if (!empty($_SESSION['form-edit-test-table']['upload_file'])) {
    if (isset($_POST['upload_file']) && !empty($_POST['upload_file'])) {
        // get filename from POST data (JSON)
        $posted_file = FileUploader::getPostedFiles($_POST['upload_file']);
        $current_file_name = $posted_file[0]['file'];
    } else {
        // get filename from Database (text)
        $current_file_name = $_SESSION['form-edit-test-table']['upload_file'];
    }
    $current_file_path = ROOT . 'uploads/files';
    if (file_exists($current_file_path . $current_file_name)) {
        $current_file_size = filesize($current_file_path . $current_file_name);
        $current_file_type = mime_content_type($current_file_path . $current_file_name);
        $current_file = array(
            'name' => $current_file_name,
            'size' => $current_file_size,
            'type' => $current_file_type,
            'file' => BASE_URL . 'uploads/files' . $current_file_name,
            'data' => array(
                'listProps' => array(
                'file' => $current_file_name
                )
            )
        );
    }
}
$fileUpload_config = array(
'upload_dir'    => '../../../../../../uploads/files', // the directory to upload the files. relative to [plugins dir]/fileuploader/[xml]/php/[uploader]
'limit'         => 1, // max. number of files
'file_max_size' => 5, // each file's maximal size in MB {null, Number}
'extensions'    => ['doc', 'doc'],
'debug'         => true
);
$form->addFileUpload('file', 'upload_file', '', 'Upload File<a href="#" data-tooltip="#' . $uniqid . '" data-delay="500" class="position-right"><span class="badge badge-secondary">?</span></a>', '', $fileUpload_config, $current_file);

// upload_image --
$form->addHtml('<span class="form-text text-muted">Upload image, 800x600 max</span>', 'upload_image', 'after');
$uniqid = uniqid();
$form->addHtml('<div id="' . $uniqid . '" style="display:none">
Upload image, 800x600 max</div>');
// get current image if exists
$current_file = '';
if (!empty($_SESSION['form-edit-test-table']['upload_image'])) {
    if (isset($_POST['upload_image']) && !empty($_POST['upload_image'])) {
        // get filename from POST data (JSON)
        $posted_file = FileUploader::getPostedFiles($_POST['upload_image']);
        $current_file_name = $posted_file[0]['file'];
    } else {
        // get filename from Database (text)
        $current_file_name = $_SESSION['form-edit-test-table']['upload_image'];
    }
    $current_file_path = ROOT . 'uploads/images';
    if (file_exists($current_file_path . $current_file_name)) {
        $current_file_size = filesize($current_file_path . $current_file_name);
        $current_file_type = mime_content_type($current_file_path . $current_file_name);
        $current_file = array(
            'name' => $current_file_name,
            'size' => $current_file_size,
            'type' => $current_file_type,
            'file' => BASE_URL . 'uploads/images' . $current_file_name,
            'data' => array(
                'listProps' => array(
                'file' => $current_file_name
                )
            )
        );
    }
}
$fileUpload_config = array(
    'xml'           => 'image-upload', // the thumbs directories must exist
    'uploader'      => 'ajax_upload_file.php', // the uploader file in phpformbuilder/plugins/fileuploader/[xml]/php
    'upload_dir'    => '../../../../../../uploads/images', // the directory to upload the files. relative to [plugins dir]/fileuploader/[xml]/php/[uploader]
    'limit'         => 1, // max. number of files
    'file_max_size' => 5, // each file's maximal size in MB {null, Number}
    'extensions'    => ['jpg', 'jpeg', 'png'],
    'thumbnails'    => false,
    'editor'        => false,
    'width'         => 800,
    'height'        => 600,
    'crop'          => false,
    'debug'         => true
);
$form->addFileUpload('file', 'upload_image', '', 'Upload Image<a href="#" data-tooltip="#' . $uniqid . '" data-delay="500" class="position-right"><span class="badge badge-secondary">?</span></a>', '', $fileUpload_config, $current_file);

// tinymce --
$form->addPlugin('tinymce', '#tinymce');
$form->addTextarea('tinymce', '', 'Tinymce', 'required, class=tinyMce, rows=10, cols=10');
$form->addBtn('button', 'cancel', 0, '<i class="' . ICON_BACK . ' position-left"></i>' . CANCEL, 'class=btn btn-warning ladda-button legitRipple, onclick=history.go(-1)', 'btn-group');
$form->addBtn('submit', 'submit-btn', 1, SUBMIT . '<i class="' . ICON_CHECKMARK . ' position-right"></i>', 'class=btn btn-success ladda-button legitRipple', 'btn-group');
$form->setCols(0, 12);
$form->centerButtons(true);
$form->printBtnGroup('btn-group');
$form->endFieldset();
$form->addPlugin('nice-check', 'form', 'default', array('%skin%' => 'green'));
