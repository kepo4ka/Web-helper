<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/pace-theme-minimal.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/themes/<?php echo BOOTSTRAP_THEME; ?>/bootstrap.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/themes/<?php echo BOOTSTRAP_THEME; ?>/admin-core.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/themes/<?php echo BOOTSTRAP_THEME; ?>/admin-theme.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/fa-svg-with-js.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/qtip.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/jquery.mCustomScrollbar.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/ripple.min.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo ADMIN_URL; ?>assets/stylesheets/footable.bootstrap.min.css" type="text/css" media="screen">

<link rel="stylesheet" href="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/themes/classic.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo CLASS_URL; ?>phpformbuilder/plugins/pickadate/lib/compressed/themes/classic.date.css" type="text/css" media="screen">
