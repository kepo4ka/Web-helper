<?php return array (
  'BA' => 'Bosna i Hercegovina',
  'ME' => 'Crna Gora',
  'ZZ' => 'Nepoznata ili nevažeća oblast',
  'RS' => 'Srbija',
  'TO' => 'Tonga',
);
